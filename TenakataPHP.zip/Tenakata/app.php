<?php

include_once './db-connect.php';

$con = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);

$action = $_POST['action'];

function GetMultiRowsData($connection, $sql) {
    $query = mysqli_query($connection, $sql);
    $result = array();
    while ($row = mysqli_fetch_assoc($query)) {
        array_push($result, $row);
    }
    if (sizeof($result, 0) > 0) {
        return $result;
    } else {
        return NULL;
    }
}

if ($action == "getall") {
    $tb = DB_TABLE;
    $sql = "SELECT * FROM $tb ORDER BY users.id DESC;";

    $data = GetMultiRowsData($con, $sql);

    die(
            json_encode(
                    !is_null($data) ?
                            $data :
                            array("error" => false, "message" => "No data available")
            )
    );
}

if ($action == "add") {
    $photo = $_POST['photo'];
    $name = $_POST['name'];
    $age = $_POST['age'];
    $maritalStatus = $_POST['maritalstatus'];
    $height = $_POST['height'];
    $gender = $_POST['gender'];
    $iq = $_POST['iq'];
    $sql = "INSERT INTO " . DB_TABLE . "(`photo`,`name`,  `maritalstatus`,  `gender`,  `age`,  `height`,  `iq`) VALUES('$photo','$name','$maritalStatus','$gender','$age',"
            . "'$height','$iq')";
//    die($sql);

    die(
            json_encode(mysqli_query($con, $sql) ? array("error" => false) : array("error" => true))
    );
}