<?php

define('DB_NAME', $_SERVER['RDS_DB_NAME']); //ebdb
define('DB_USER', $_SERVER['RDS_USERNAME']);//root
define('DB_PASSWORD', $_SERVER['RDS_PASSWORD']); //tenakata
define('DB_HOST', $_SERVER['RDS_HOSTNAME']);//mydatabase.ctbsus3xjz33.eu-central-1.rds.amazonaws.com
define('DB_TABLE', 'users');

//define('DB_NAME', "tenakata");
//define('DB_USER', "root");
//define('DB_PASSWORD', "");
//define('DB_HOST', "localhost");
//define('DB_TABLE', 'users');
?>